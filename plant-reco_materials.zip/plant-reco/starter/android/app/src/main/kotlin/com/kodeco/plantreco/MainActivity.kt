package com.kodeco.plantreco

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
